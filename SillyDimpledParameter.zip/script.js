let name 
do {
   name = prompt ("Digite seu nome");
document.getElementById ("name").innerHTML = name;
} while (!name); 

let decision = window.confirm ( "Deseja jogar?");
if (decision) {
 let question1 = prompt("Qual a capital do Brasil?")

  if (question1 === "Brasilia") {
    console.log("ok")
    document.getElementById ("question1").innerHTML = "A resposta é Brasilia, sua resposta esta correta!";
  } else {
    document.getElementById ("question1").innerHTML = "A resposta é Brasilia, sua resposta esta errada.";
  }

  let question2 = prompt ("Qual a raiz quadrada de 49?")
if (question2 === "7") {
    document.getElementById ("question2").innerHTML = "A raiz quadrada de 49 é 7, sua resposta esta correta!";
  } else {
    document.getElementById ("question1").innerHTML = "A raiz quadrada de 49 é 7, sua resposta esta errada!"
  }

  let question3 = prompt ("Quanto é 50/5?")
  if (question3 === "10") {
    document.getElementById ("question3").innerHTML = "A divisão de 50 po 5 é 10, sua resposta esta correta!"
  } else  {
    document.getElementById ("question3").innerHTML = "A divisão de 50 por 5 é 10, sua resposta esta errada!"
} 
 } else {
  document.write ("Obrigada, até a próxima, " + name + "!")
}
